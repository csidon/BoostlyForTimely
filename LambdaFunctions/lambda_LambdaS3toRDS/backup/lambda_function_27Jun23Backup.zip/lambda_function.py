import json
import boto3
import psycopg2
from dateutil import parser
from psycopg2 import sql
from psycopg2 import errors
from datetime import datetime
import pytz       # Brings in the Olson tz database into python

UniqueViolation = errors.lookup('23505')

# IMPORTANT NOTE: This script is an MVP and does not take timezones into account. All datetime objects stored in database are assumed to be NZT

#######################################################################
# SECTION 1: DATABASE CONNECTION VARIABLES
s3 = boto3.client('s3')
lam = boto3.client('lambda', region_name='us-east-1')
# rds settings
rds_host  = 's3-lambda-rdspostgresv2.clbvaq8mp9jk.us-east-1.rds.amazonaws.com'
user_name = 'postgresmaster'
password = '1NewPass!'
db_name = 'boostly_db'
port = 5432

#######################################################################
# SECTION 2: CLASSES 
# -- DESERIALISING JSON STRING TO AN OBJECT
# This class turns json keys into objects, but is specific to the Event table
class Event:
    def __init__(self, json_def):
        s = json.loads(json_def)
        self.cal_event_uid = None if 'cal_event_uid' not in s else s['cal_event_uid']
        self.event_owner = None if 'event_owner' not in s else s['event_owner']
        self.status = None if 'status' not in s else s['status']
        self.event_start = None if 'event_start' not in s else s['event_start']
        self.event_end = None if 'event_end' not in s else s['event_end']
        self.event_updated = None if 'event_updated' not in s else s['event_updated']
        self.event_summ = None if 'event_summ' not in s else s['event_summ']


#######################################################################
# SECTION 3: CONNECT TO RDS POSTGRESQL DB

def connectToRDS(tablename):
    try:
        conn = psycopg2.connect(
            database=db_name,
            user=user_name,
            password=password,
            host=rds_host,
            port=port
            )
        print("DB connection established")

    except psycopg2.OperationalError as e:
        # pass exception to function
        print(e)
        # set the connection to 'None' in case of error
        conn = None
    return conn
    # DON'T FORGET TO CLOSE THE CONNECTION AFTER!


#---------------------------------------------

def lambda_handler(event, context):
    print(json.dumps(event))
    # Step 1: Connect to DB and check tables are created
    tablename = 'event'
    conn = connectToRDS(tablename)      # This might be done outside the function, but kept inside for testing purposes
    
    # Step 2: Getting record information for inputting into database
    # Fetching bucket name
    bucket = event['Records'][0]['s3']['bucket']['name']
    print("Bucket name = " + bucket)
    
    # Fetching file name (also the key)
    json_filename = event['Records'][0]['s3']['object']['key']
    print("Bucket key = " + json_filename)
    
    ### TO ASK ARTHUR IF THIS CAN BE MADE MORE EFFICIENT!!
    #### Create a cache! Cloudfront? does Lambda have a cache? 
    # Getting the contents of json file
    json_object = s3.get_object(Bucket=bucket, Key=json_filename)       # LAMBDA: This gets a dict of everything in the json object, including headers -- uncomment if testing on Lambda!

    # print(json_object)
    reading_json_object = json_object['Body'].read().decode("utf-8")    # LAMBDA: This decodes it so it only shows the content, but turns it into a string
    # print("reading_json_obj before conversion is: " + reading_json_object)


    # e = Event(testJsonstring)               # LOCALTEST
    e = Event(reading_json_object)        # LAMBDA: Values are now objects

    print("EventSummary: " + str(e.event_summ) + "And the status for the event is: " + e.status)
    print(type(e.status))
    print("The data of event_start coming from Google Apps Script should be timezone aware with IS0 8601 format 'YYYY-MM-DDTHH:MM:SS+12:00: " + str(e.event_start))
    print("The datatype for event_start received by the lambda(event) is: " + str(type(e.event_start)))

    # This script is an MVP and does not take timezones into account. All datetime objects stored in database are assumed to be NZT

    # If the event is cancelled, gCal only sends back the id and status,  
    # so regardless of status, we need to check the db and see if the event exists, then pull the events' existing data if it exists.
    with conn:
        try:
            cursor = conn.cursor()      # Creating a new cursor object

            # Searching in RDS to see if record exists
            event_exists = """ SELECT * FROM Event WHERE cal_event_uid = %s """
            cursor.execute(event_exists, (e.cal_event_uid,))
            does_exist = cursor.fetchall()

            print("Check num of rows that have CalUID == e.CalUID: " + str(cursor.rowcount))

            if cursor.rowcount > 0:
                print("Event exists! The client has either cancelled or moved the appointment slot. \nWe need to notify the business owner in either case." +
                      "\nCollecting details of the outdated appointment...")
                # Update Event table with the event's start and end times, then trigger the alertBusinessOwners lambda rule
                
                print("Print each row from RDS that fulfils calUID == calUID conditions")
                cal_id = ""
                free_owner = ""
                free_start = ""
                free_end = ""
                for row in does_exist:
                    cal_id = str(row[1])
                    free_owner = row[2]      
                    free_start = row[4]
                    free_end = row[5]
                    print("calId = " + cal_id + "<-- This ID should NOT be NULL!" )
                    print("eventOwner = ", free_owner)
                print("The calEventUID in the row retrieved is: " + cal_id)
                print("Free slot start time is " + str(free_start) + " and the datatype is " + str(type(free_start)))

                # Calculating the slot length using freeStart and freeEnd
                t1 = datetime.strptime(str(free_start), "%Y-%m-%d %H:%M:%S")
                t2 = datetime.strptime(str(free_end), "%Y-%m-%d %H:%M:%S")
                delta_mins = (t2-t1).total_seconds()/60
                delta_mins_int = "{:.0f}".format(delta_mins)
                print("Time difference is " + delta_mins_int + " minutes")

                # We don't want to lose this information if, for whatever reason, the message isn't sent. So we store this in a table
                print("Creating a temp waitlist alert record into the TempWaitAlert table")
                sending_timestamp = str(datetime.now())
                try:
                    insert_val =  """ INSERT into temp_wait_alert (slot_start_date_time, slot_length, last_updated)       
                                    VALUES (%s, %s, %s) 
                                    RETURNING id """
                    cursor.execute(insert_val, (free_start, delta_mins_int, sending_timestamp))
                    conn.commit()
                    id_of_new_row = cursor.fetchone()[0]
                    print("Alert details added to TempWaitAlert table. alertID = " + str(id_of_new_row))
                except (Exception, psycopg2.Error) as error:
                    print("Failed to update RDS TempWaitAlert table. Err message: " + str(error))

                # With this information, we can create the payload for the message. 
                # Defining input parameters (payload) passed on to next lambda function
                sending_timestamp = str(datetime.now())
                inputParams = {
                    "alertID" : str(id_of_new_row),
                    "freeCalID" : cal_id,
                    "freeOwner" : free_owner,
                    "freeStatus" : e.status,        # We can use the event status passed from gApps. This should be either "cancelled" or "moved".
                    "freeStart" : str(free_start),
                    "freeDuration" : delta_mins_int,
                    "sendingTimestamp" : sending_timestamp
                }
                print("The inputParams you're sending is of datatype: " + str(type(inputParams)) + " \n with data of: " + str(inputParams))
                print("The format type for sending_timestamp is: " + str(type(str(datetime.now()))))
                # Trigger child function and pass payload
                try:
                    response = lam.invoke(
                        FunctionName = 'arn:aws:lambda:us-east-1:594073251416:function:childFunction-alertBusinessOwners',
                        InvocationType = 'RequestResponse',
                        Payload = json.dumps(inputParams)
                    )
                    responseFromChild = json.load(response['Payload'])
                    print("The response from the alertBusinessOwners lambda function is: " + str(responseFromChild))
                except (Exception, psycopg2.Error) as error:
                    print("Failed to trigger 'alertBusinessOwners' child lambda function for moved/cancelled event. Err message: " + str(error))

                # Now we update the Event table
                # We process the data slightly differently depending on whether it's cancelled or moved
                try:
                    if e.status=='confirmed':
                        print("Status is confirmed!")
                        update_val = """ UPDATE Event SET (event_start, event_end, event_updated) = (%s, %s, %s) where cal_event_uid = %s """
                        cursor.execute(update_val, (e.event_start, e.event_end, e.event_updated, e.cal_event_uid))
                        conn.commit()
                        print("Event updated in Event table. The business owner should have received a notification!")

                    elif e.status == 'cancelled':
                        print("Status is cancelled!")
                        update_val = """ UPDATE Event SET (status, event_updated) = (%s, %s) where cal_event_uid = %s """
                        cursor.execute(update_val, (e.status, sending_timestamp, e.cal_event_uid))
                        conn.commit()
                        print("Event updated in Event table. The business owner should have received a notification!")
                except (Exception, psycopg2.Error) as error:
                    print("Failed to update RDS Event table for moved/cancelled event. Err message: " + str(error))
            
            else:       # If rowcount is 0, this is a new event
                print("Event does not exist, inserting Event into Event table..")
                # Event does not exist. Insert data from gCal event object into RDS Event table
                try:
                    insert_val =  """ INSERT into Event (cal_event_uid, event_owner, status, event_start, event_end, event_updated)       
                                    VALUES (%s, %s, %s, %s, %s, %s) """
                    cursor.execute(insert_val, (e.cal_event_uid, e.event_owner, e.status, e.event_start, e.event_end, e.event_updated))
                    conn.commit()
                    print("Event inserted into Event table. No need to send out any notifications!")
                except (Exception, psycopg2.Error) as error:
                    print("Failed to update RDS Event table for new event. Err message: " + str(error))

        except (Exception, psycopg2.Error) as error:
                print("Failed to search Event table. Err message: " + str(error))


testevent = {
    "Records": [
        {
            "eventVersion": "2.1",
            "eventSource": "aws:s3",
            "awsRegion": "us-east-1",
            "eventTime": "2023-05-30T06:45:06.268Z",
            "eventName": "ObjectCreated:Put",
            "userIdentity": {
                "principalId": "AWS:AIDAYUUMGNZMJLLUCBGDJ"
            },
            "requestParameters": {
                "sourceIPAddress": "34.116.22.95"
            },
            "responseElements": {
                "x-amz-request-id": "M12A26QNXTV5ZP1N",
                "x-amz-id-2": "UrD0R2BHLUJnaaq2Jh+LheslgblIezQpfxk0EIiZA8hDjqjonQxo206DQYLBuSB+vE/r9YBH44xmpkYU0CKMXRiY06sMAy/lMsEqQnh/6AA="
            },
            "s3": {
                "s3SchemaVersion": "1.0",
                "configurationId": "8a8c8350-5995-4731-af13-c5eb2a42c894",
                "bucket": {
                    "name": "appscript-bucket",
                    "ownerIdentity": {
                        "principalId": "A1U0OVFHZ6AK9M"
                    },
                    "arn": "arn:aws:s3:::appscript-bucket"
                },
                "object": {
                    "key": "6diiipdhiflt44smpeq9afkkc4.json",
                    "size": 228,
                    "eTag": "55330af1ae66cbc3f19f1d32366ce113",
                    "sequencer": "0064759B72355F91D3"
                }
            }
        }
    ]
}

# testJsonObject = {'ResponseMetadata': {'RequestId': '5TPAK38S2WG3ZPZW', 'HostId': 'f6qxmW7/+0D15r6ZoXe0hHVYg5EDwKRZoH/RMQwFXHF7GnijIihrCiPteoaNWM/W8JpGYrHVUOIcBWq8fio4bg==', 'HTTPStatusCode': 200, 'HTTPHeaders': {'x-amz-id-2': 'f6qxmW7/+0D15r6ZoXe0hHVYg5EDwKRZoH/RMQwFXHF7GnijIihrCiPteoaNWM/W8JpGYrHVUOIcBWq8fio4bg==', 'x-amz-request-id': '5TPAK38S2WG3ZPZW', 'date': 'Wed, 07 Jun 2023 05:46:10 GMT', 'last-modified': 'Wed, 31 May 2023 04:43:07 GMT', 'etag': '"29a102190c8bc7aaa4fb6ecef7cc4823"', 'x-amz-server-side-encryption': 'AES256', 'accept-ranges': 'bytes', 'content-type': 'application/json', 'server': 'AmazonS3', 'content-length': '168'}, 'RetryAttempts': 0}, 'AcceptRanges': 'bytes', 'LastModified': datetime.datetime(2023, 5, 31, 4, 43, 7, tzinfo=tzutc()), 'ContentLength': 168, 'ETag': '"29a102190c8bc7aaa4fb6ecef7cc4823"', 'ContentType': 'application/json', 'ServerSideEncryption': 'AES256', 'Metadata': {}, 'Body': <botocore.response.StreamingBody object at 0x7fc717cad490>}
testJsonstring = "{\"cal_event_uid\":\"3dssafibq1agrg3kp8gu4kne5k\",\"event_owner\":\"fakerachellette@gmail.com\",\"status\":\"confirmed\",\"event_start\":\"2023-06-02T17:45:00+12:00\",\"event_end\":\"2023-06-02T18:15:00+12:00\",\"event_updated\":\"2023-06-02T03:03:16.944Z\",\"event_summ\":\"Fakee ChrisAnother458\"}"

# lambda_handler(testevent, "")

# except (Exception, psycopg2.DatabaseError) as error:
#         print(error)
# finally:
#     if conn is not None:
#         conn.close()

#### NOT YET INSERTED!!!
# #For testing - Example of what a pulled event obj will look like:
# event_obj = {"calEventUID":"0v4fs27ntvr0d8nqo8v1uve7j5","eventOwner":"boostlymagic@gmail.com","status":"confirmed","eventStart":"2023-05-12T11:15:00+12:00","eventEnd":"2023-05-16T22:45:00+12:00","eventUpdated":"2023-05-16T05:56:33.006Z"}


# eventStart = event_obj['eventStart']

# event_date = eventStart # Assigning event_date to eventStart

# employingID = 1 # Not yet done, assuming we're accessing EmployeeID 1 for now
# # clientID = 1    # Simulating Chris record
 

# event_date = parser.parse(event_date, yearfirst=True, dayfirst=True)    # Converts date string to datetime format
# event_day = event_date.strftime('%A')                                   # Gets the day of the event
# event_time = event_date.hour                                            # Checks the starting hour of the event
# if event_time < 12:
#     event_timeofday = event_day + "AM"                                 # Concatenates to create a string with "daytype_timeofday"
# else:
#     event_timeofday = event_day + "PM"

# # event_date = event_date.strftime("%d-%m-%y")

# print("event time  is ", event_timeofday)
# print("day of e_date is: ", event_day)
# # print("event date converted is ", event_date)

# # Now to check client preference table to see if there's anyone who wants that timeslot
# def iter_row(cursor, size=10):
#     while True:
#         rows = cursor.fetchmany(size)
#         if not rows:
#             break
#         for row in rows:
#             yield row

# try:
#     cursor = conn.cursor()
#     check_pref = """ SELECT * FROM ClientPref
#                         WHERE employID=%s """ 
#     cursor.execute(check_pref, (str(employingID)))
#     record = cursor.fetchall()
#     # for row in iter_row(cursor, 10):
#     #             print(row)
#     print(record)
#     print(record[0][2])
#     cursor.close()

# except (Exception, psycopg2.DatabaseError) as error:
#         print(error)
# finally:
#     if conn is not None:
#         conn.close()

#### --END NOT YET INSERTED!!!



# """ CREATE TABLE if not exists Event ( 
#     calEventUID varchar(255) NOT NULL, 
#     eventOwner varchar(255) NOT NULL, 
#     status varchar(255) NOT NULL, 
#     eventStart Date NOT NULL, 
#     eventEnd Date NOT NULL, 
#     eventUpdated Date NOT NULL, PRIMARY KEY (calEventUID)) """

# """ CREATE TABLE if not exists Client ( 
#     clientID SERIAL PRIMARY KEY, 
#     clientFirstName VARCHAR(255) NOT NULL, 
#     clientLastName VARCHAR(255) NOT NULL, 
#     clientEmail VARCHAR(255) NOT NULL, 
#     clientMobile INT NOT NULL) """

# """ CREATE TABLE if not exists AvailTimes ( 
#     availID SERIAL PRIMARY KEY,
#     days VARCHAR(16) UNIQUE) """

# 'ERROR:  duplicate key value violates unique constraint "availtimes_days_key"'

# """ 
# BEGIN
    # INSERT INTO AvailTimes (days)
    # VALUES 
    # ('MondayAM'), ('MondayAM'), ('MondayPM'), ('TuesdayAM'), ('TuesdayPM'), ('WednesdayAM'), ('WednesdayPM'), 
    # ('ThursdayAM'), ('ThursdayPM'), ('FridayAM'), ('FridayPM'), ('SaturdayAM'), ('SaturdayPM'),
    # ('SundayAM'), ('SundayPM');
# EXCEPTION WHEN unique_violation THEN
    # -- do nothing
# END; """

# """ CREATE TABLE if not exists ClientPref ( 
#     clientID INT NOT NULL PRIMARY KEY,
#     employID INT NOT NULL, 
#     availID INT NOT NULL,
#     minDuration INT not null) """


# DUMMY DATA
# """ INSERT INTO Client (clientFirstName, clientLastName, clientEmail, clientMobile)
# VALUES 
# ('Chris', 'Chong', 'chris.chonghuihui@gmail.com', '0220660122') ,
# ('Ana', 'Karpova', 'ana@gmail.com', '1234567'),
# ('Lala', 'Wally', 'lala@gmail.com', '9876543') """

# Data needed for Employee table: employeeID, companyID, emailAddress, 


# Dummy values inserting all mornings into Chris (client1), all afternoons into Ana (client2), and mixed bag into lala for Employee1
# """ INSERT INTO ClientPref
# VALUES 
# (1, 1, 1), (1, 1, 3), (1, 1, 5), (1, 1, 7), (1, 1, 9),
# (1, 1, 11), (1, 1, 13),
# (2, 1, 2), (2, 1, 4), (2, 1, 6), (2, 1, 8), (2, 1, 10),
# (2, 1, 12), (2, 1, 14),
# (3, 1, 1), (3, 1, 2), (3, 1, 6), (3, 1, 7), (3, 1, 14)"""