import json
import boto3
import psycopg2
from dateutil import parser
from psycopg2 import sql
from psycopg2 import errors
from datetime import datetime
import pytz       # Brings in the Olson tz database into python

UniqueViolation = errors.lookup('23505')

# IMPORTANT NOTE: This script is an MVP and does not take timezones into account. All datetime objects stored in database are assumed to be NZT

#######################################################################
# SECTION 1: DATABASE CONNECTION VARIABLES
s3 = boto3.client('s3')
lam = boto3.client('lambda', region_name='us-east-1')
# rds settings
rds_host  = 's3-lambda-rdspostgresv2.clbvaq8mp9jk.us-east-1.rds.amazonaws.com'
user_name = 'postgresmaster'
password = '1NewPass!'
db_name = 'boostly_db'
port = 5432

#######################################################################
# SECTION 2: CLASSES 
# -- DESERIALISING JSON STRING TO AN OBJECT
# This class turns json keys into objects, but is specific to the Event table
class Event:
    def __init__(self, json_def):
        s = json.loads(json_def)
        self.calEventUID = None if 'calEventUID' not in s else s['calEventUID']
        self.eventOwner = None if 'eventOwner' not in s else s['eventOwner']
        self.status = None if 'status' not in s else s['status']
        self.eventStart = None if 'eventStart' not in s else s['eventStart']
        self.eventEnd = None if 'eventEnd' not in s else s['eventEnd']
        self.eventUpdated = None if 'eventUpdated' not in s else s['eventUpdated']
        self.eventSumm = None if 'eventSumm' not in s else s['eventSumm']

#######################################################################
# SECTION 3: CONNECT TO RDS POSTGRESQL DB
# On successful connection to DB, check to see if tables are created and set up correctly

def setupRDS(conn):
    #--- Checking/creating Event Table 
    # Going to ignore timezones for this implementation. All data stored to RDS is assumed in NZT (UTC+12)
    with conn:
        try:
            create_event_table = """CREATE TABLE if not exists Event ( 
                eventID SERIAL PRIMARY KEY,
                calEventUID varchar(100) NOT NULL, 
                eventOwner varchar(120) NOT NULL, 
                status varchar(30) NOT NULL, 
                Eventtart TIMESTAMP NOT NULL, 
                eventEnd TIMESTAMP NOT NULL, 
                eventUpdated TIMESTAMP NOT NULL)"""           
            cursor = conn.cursor()
            cursor.execute(create_event_table)
            conn.commit()
            print("Event table created successfully")
            
        except psycopg2.Error as e:
            print(e)
    #--- Checking/creating Employee Table (TBD) *************

    #--- Checking/creating Client Table
    with conn:
        try:
            create_client_table =  """ CREATE TABLE if not exists Client ( 
                clientID SERIAL PRIMARY KEY, 
                clientFirstName VARCHAR(100) NOT NULL, 
                clientLastName VARCHAR(100) NOT NULL, 
                clientEmail VARCHAR(120) NOT NULL, 
                clientMobile INT NOT NULL) """
            cursor.execute(create_client_table)
            conn.commit()
            print("Client table created successfully")
        except psycopg2.Error as e:
            print(e)
                                    
    #--- Checking/creating TimesAvailable Table
    with conn:
        try:
            create_times_table =  """ CREATE TABLE if not exists AvailTimes ( 
                availID SERIAL PRIMARY KEY,
                days VARCHAR(30) UNIQUE) """
            cursor.execute(create_times_table)
            conn.commit()
            print("Times Available table created successfully")
        except psycopg2.Error as e:
            print(e)
            print("Failed to create TimesAvail table", error)

    with conn:
        try:
            insert_times_table = """
                INSERT INTO AvailTimes (days)
                VALUES
                ('MondayAM'), ('MondayPM'), ('TuesdayAM'), ('TuesdayPM'), 
                ('WednesdayAM'), ('WednesdayPM'), ('ThursdayAM'), ('ThursdayPM'), 
                ('FridayAM'), ('FridayPM'), ('SaturdayAM'), ('SaturdayPM'),
                ('SundayAM'), ('SundayPM') """
            cursor.execute(insert_times_table)
            conn.commit()
            count = cursor.rowcount
            print(count, "Dummy records inserted successfully into imesAvail table")
        except (Exception, psycopg2.Error) as error:
            print("Failed to insert dummy record into TimesAvail table", error)
            
    #--- Checking/creating ClientPref Table
    with conn:
        try:
            create_clientPref_table =  """ CREATE TABLE if not exists ClientPref ( 
                cprefID SERIAL PRIMARY KEY,
                clientID INT NOT NULL,
                employID INT NOT NULL, 
                availID INT NOT NULL,
                minDuration INT NOT NULL DEFAULT 30,
                lastNotified TIMESTAMP,
                lastClicked TIMESTAMP,
                lastUpdated TIMESTAMP NOT NULL DEFAULT NOW() ) """
            cursor.execute(create_clientPref_table)
            conn.commit()
            print("ClientPref table created successfully")
        except psycopg2.Error as e:
            print(e)

    #--- Checking/creating ClientEngage Table
    with conn:
        try:
            create_clientEngage_table =  """ CREATE TABLE if not exists ClientEngage ( 
                clientID INT NOT NULL,
                employID INT NOT NULL, 
                lastNotified TIMESTAMP,
                lastClicked TIMESTAMP,
                timesClicked INT NOT NULL DEFAULT 0,
                dateFirstAdded TIMESTAMP NOT NULL DEFAULT NOW() ) """
            cursor.execute(create_clientEngage_table)
            conn.commit()
            print("ClientEngage table created successfully")
        except psycopg2.Error as e:
            print(e)

    with conn:
        cursor = conn.cursor()      # Creating a new cursor object
        try:
            # AlertID = primary key. This is different to the calUID 
            create_tempWaitAlert_table =  """ CREATE TABLE if not exists TempWaitAlert ( 
                alertID SERIAL PRIMARY KEY, 
                calID varchar(100) NOT NULL, 
                freeOwner varchar(100) NOT NULL, 
                status varchar(30) NOT NULL, 
                freeStart TIMESTAMP NOT NULL, 
                freeEnd TIMESTAMP NOT NULL, 
                createdTimestamp TIMESTAMP NOT NULL DEFAULT NOW() )""" 
            cursor.execute(create_tempWaitAlert_table)
            conn.commit()
            print("TempWaitAlert table created successfully")
        except psycopg2.Error as e:
            print(e)
    insert_dummy_data(conn)
        # ********TO CREATE THE BUSINESS OWNERS' AND EMPLOYEES TABLE! IMPT!!!** EMPLOYEES TABLE SHOULD INCLUDE TIMEZONE USING THE IANA timezone identifier!!***

def checkTableNotExists(conn, tablename):
    cursor = conn.cursor()

    check_table = """ SELECT count(*) FROM INFORMATION_SCHEMA.TABLES 
                        WHERE TABLE_SCHEMA = 'public'
                         AND TABLE_NAME = %s """
    cursor.execute(check_table, (tablename, ))
    res = cursor.fetchone()
    print("What's the cursors' answer?: " + str(res) + " with datatype: " + str(type(res)) + " and res[0]=" + str(res[0]))
    
    if res[0] == 1:
        print("TableNotExists = FALSE.. the table exists!")
        return False
    print("TableNotExists = TRUE.. Table doesn't exist")
    return True

def connectToRDS(tablename):
    try:
        conn = psycopg2.connect(
            database=db_name,
            user=user_name,
            password=password,
            host=rds_host,
            port=port
            )
        print("DB connection established")

        # Checks if Event table exists. If it does, it means that the database should be set up and we can skip the setup process, otherwise setup database
        # Using with statement because that terminates transactions that don't succeed without closing the connection
        
        print("checking if " + tablename + " table exists...")
        if checkTableNotExists(conn, tablename): 
            print("Event table doesn't exist. Setting up database...")
            setupRDS(conn)
        else:
            print("Event table exists! Moving on...")

    except psycopg2.OperationalError as e:
        # pass exception to function
        print(e)
        # set the connection to 'None' in case of error
        conn = None
    return conn
    # DON'T FORGET TO CLOSE THE CONNECTION AFTER!

def insert_dummy_data(conn):
    cursor = conn.cursor()      # Creating a new cursor object
    with conn:
        try:
            insert_dummy_clients = """ INSERT into Client
                VALUES
                (1, 'Chris', 'Chong', 'chris.chonghuihui@gmail.com', '0220660122'),
                (2, 'Ana', 'Karpova', 'ana@gmail.com', '1234567'),
                (3, 'Lala', 'Wally', 'lala@gmail.com', '9876543') """
            cursor.execute(insert_dummy_clients)
            conn.commit()
            count = cursor.rowcount
            print(count, "Dummy records inserted successfully into Client table")
        except (Exception, psycopg2.Error) as error:
            print("Failed to insert dummy record into Client table", error)
    with conn:
        try:
            insert_dummy_clientPrefs = """ INSERT into ClientPref 
                VALUES
                (1, 1, 1), (1, 1, 3), (1, 1, 5), (1, 1, 7), (1, 1, 9),
                (1, 1, 11), (1, 1, 13),
                (2, 1, 2), (2, 1, 4), (2, 1, 6), (2, 1, 8), (2, 1, 10),
                (2, 1, 12), (2, 1, 14),
                (3, 1, 1), (3, 1, 2), (3, 1, 6), (3, 1, 7), (3, 1, 14) """  
            cursor.execute(insert_dummy_clientPrefs)
            conn.commit()
            count = cursor.rowcount
            print(count, "Dummy records inserted successfully into ClientPref table")   # Need to check and remove duplicates if updating!
        except (Exception, psycopg2.Error) as error:
            print("Failed to insert dummy record into ClientPref table", error)

#---------------------------------------------

def lambda_handler(event, context):
    print(json.dumps(event))
    # Step 1: Connect to DB and check tables are created
    tablename = 'event'
    conn = connectToRDS(tablename)      # This might be done outside the function, but kept inside for testing purposes
    
    # Step 2: Getting record information for inputting into database
    # Fetching bucket name
    bucket = event['Records'][0]['s3']['bucket']['name']
    print("Bucket name = " + bucket)
    
    # Fetching file name (also the key)
    json_filename = event['Records'][0]['s3']['object']['key']
    print("Bucket key = " + json_filename)
    
    ### TO ASK ARTHUR IF THIS CAN BE MADE MORE EFFICIENT!!
    #### Create a cache! Cloudfront? does Lambda have a cache? 
    # Getting the contents of json file
    json_object = s3.get_object(Bucket=bucket, Key=json_filename)       # This gets a dict of everything in the json object, including headers -- uncomment if testing on Lambda!
    print(json_object)
    # json_object = testJsonObject                                                # Test S3 object below. -- Comment out if testing on lambda!!
    # print(json_object)
    reading_json_object = json_object['Body'].read().decode("utf-8")    # This decodes it so it only shows the content, but turns it into a string
    # print("reading_json_obj before conversion is: " + reading_json_object)
    
    e = Event(reading_json_object)      # Values are now objects
    print("EventSummary: " + e.eventSumm + "And the status for the event is: " + e.status)
    print(type(e.status))
    print("The data of eventStart coming from Google Apps Script should be timezone aware with IS0 8601 format 'YYYY-MM-DDTHH:MM:SS+12:00: " + e.eventStart)
    print("The datatype for eventStart received by the lambda(event) is: " + str(type(e.eventStart)))

    # This script is an MVP and does not take timezones into account. All datetime objects stored in database are assumed to be NZT

    # If the event is cancelled, gCal only sends back the id and status,  
    # so regardless of status, we need to check the db and see if the event exists, then pull the events' existing data if it exists.
    with conn:
        try:
            cursor = conn.cursor()      # Creating a new cursor object

            # Searching in RDS to see if record exists
            event_exists = """ SELECT * FROM Event WHERE calEventUID = %s """
            cursor.execute(event_exists, (e.calEventUID,))
            does_exist = cursor.fetchall()

            print("Check num of rows that have CalUID == e.CalUID: " + str(cursor.rowcount))

            if cursor.rowcount > 0:
                print("Event exists! The client has either cancelled or moved the appointment slot. \nWe need to notify the business owner in either case." +
                      "\nCollecting details of the outdated appointment...")
                # Update Event table with the event's start and end times, then trigger the alertBusinessOwners lambda rule
                
                print("Print each row from RDS that fulfils calUID == calUID conditions")
                calID = ""
                freeOwner = ""
                freeStart = ""
                freeEnd = ""
                for row in does_exist:
                    calID = row[0]
                    freeOwner = row[1]      
                    freeStart = row[3]
                    freeEnd = row[4]
                    print("calId = " + calID + "<-- This ID should NOT be NULL!" )
                    print("eventOwner = ", row[1])
                print("The calEventUID in the row retrieved is: " + calID)
                print("Free slot start time is " + str(freeStart) + " and the datatype is " + str(type(freeStart)))

                # Calculating the slot length using freeStart and freeEnd
                t1 = datetime.strptime(freeStart, "%Y-%m-%d %H:%M:%S")
                t2 = datetime.strptime(freeEnd, "%Y-%m-%d %H:%M:%S")
                deltaMins = (t2-t1).total_seconds()/60
                deltaMinsnInt = "{:.0f}".format(deltaMins)
                print("Time difference is " + deltaMinsnInt + " minutes")

                # We don't want to lose this information if, for whatever reason, the message isn't sent. So we store this in a table
                print("Creating a temp waitlist alert record into the TempWaitAlert table")
                sendingTimestamp = str(datetime.now())
                try:
                    insert_val =  """ INSERT into TempWaitAlert (slotStartDateTime, slotLength, lastUpdated)       
                                    VALUES (%s, %s, %s) 
                                    RETURNING id """
                    cursor.execute(insert_val, (freeStart, deltaMinsnInt, sendingTimestamp))
                    conn.commit()
                    id_of_new_row = cursor.fetchone()[0]
                    print("Alert details added to TempWaitAlert table. alertID = " + str(id_of_new_row))
                except (Exception, psycopg2.Error) as error:
                    print("Failed to update RDS TempWaitAlert table. Err message: " + str(error))

                # With this information, we can create the payload for the message. 
                # Defining input parameters (payload) passed on to next lambda function
                sendingTimestamp = str(datetime.now())
                inputParams = {
                    "alertID" : str(id_of_new_row),
                    "freeCalID" : calID,
                    "freeOwner" : freeOwner,
                    "freeStatus" : e.status,        # We can use the event status passed from gApps. This should be either "cancelled" or "moved".
                    "freeStart" : str(freeStart),
                    "freeDuration" : deltaMinsnInt,
                    "sendingTimestamp" : sendingTimestamp
                }
                print("The inputParams you're sending is of datatype: " + str(type(inputParams)) + " \n with data of: " + str(inputParams))
                print("The format type for sendingTimestamp is: " + str(type(str(datetime.now()))))
                # Trigger child function and pass payload
                try:
                    response = lam.invoke(
                        FunctionName = 'arn:aws:lambda:us-east-1:594073251416:function:childFunction-alertBusinessOwners',
                        InvocationType = 'RequestResponse',
                        Payload = json.dumps(inputParams)
                    )
                    responseFromChild = json.load(response['Payload'])
                    print("The response from the alertBusinessOwners lambda function is: " + str(responseFromChild))
                except (Exception, psycopg2.Error) as error:
                    print("Failed to trigger 'alertBusinessOwners' child lambda function for moved/cancelled event. Err message: " + str(error))

                # Now we update the Event table
                # We process the data slightly differently depending on whether it's cancelled or moved
                try:
                    if e.status=='confirmed':
                        print("Status is confirmed!")
                        update_val = """ UPDATE Event SET (eventStart, eventEnd, eventUpdated) = (%s, %s, %s) where calEventUID = %s """
                        cursor.execute(update_val, (e.eventStart, e.eventEnd, e.eventUpdated, e.calEventUID))
                        conn.commit()
                        print("Event updated in Event table. The business owner should have received a notification!")

                    elif e.status == 'cancelled':
                        print("Status is cancelled!")
                        update_val = """ UPDATE Event SET (status, eventUpdated) = (%s, %s) where calEventUID = %s """
                        cursor.execute(update_val, (e.status, sendingTimestamp, e.calEventUID))
                        conn.commit()
                        print("Event updated in Event table. The business owner should have received a notification!")
                except (Exception, psycopg2.Error) as error:
                    print("Failed to update RDS Event table for moved/cancelled event. Err message: " + str(error))
            
            else:       # If rowcount is 0, this is a new event
                print("Event does not exist, inserting Event into Event table..")
                # Event does not exist. Insert data from gCal event object into RDS Event table
                try:
                    insert_val =  """ INSERT into Event (calEventUID, eventOwner, status, eventStart, eventEnd, eventUpdated)       
                                    VALUES (%s, %s, %s, %s, %s, %s) """
                    cursor.execute(insert_val, (e.calEventUID, e.eventOwner, e.status, e.eventStart, e.eventEnd, e.eventUpdated))
                    conn.commit()
                    print("Event inserted into Event table. No need to send out any notifications!")
                except (Exception, psycopg2.Error) as error:
                    print("Failed to update RDS Event table for new event. Err message: " + str(error))

        except (Exception, psycopg2.Error) as error:
                print("Failed to search Event table. Err message: " + str(error))


testevent = {
    "Records": [
        {
            "eventVersion": "2.1",
            "eventSource": "aws:s3",
            "awsRegion": "us-east-1",
            "eventTime": "2023-05-30T06:45:06.268Z",
            "eventName": "ObjectCreated:Put",
            "userIdentity": {
                "principalId": "AWS:AIDAYUUMGNZMJLLUCBGDJ"
            },
            "requestParameters": {
                "sourceIPAddress": "34.116.22.95"
            },
            "responseElements": {
                "x-amz-request-id": "M12A26QNXTV5ZP1N",
                "x-amz-id-2": "UrD0R2BHLUJnaaq2Jh+LheslgblIezQpfxk0EIiZA8hDjqjonQxo206DQYLBuSB+vE/r9YBH44xmpkYU0CKMXRiY06sMAy/lMsEqQnh/6AA="
            },
            "s3": {
                "s3SchemaVersion": "1.0",
                "configurationId": "8a8c8350-5995-4731-af13-c5eb2a42c894",
                "bucket": {
                    "name": "appscript-bucket",
                    "ownerIdentity": {
                        "principalId": "A1U0OVFHZ6AK9M"
                    },
                    "arn": "arn:aws:s3:::appscript-bucket"
                },
                "object": {
                    "key": "6diiipdhiflt44smpeq9afkkc4.json",
                    "size": 228,
                    "eTag": "55330af1ae66cbc3f19f1d32366ce113",
                    "sequencer": "0064759B72355F91D3"
                }
            }
        }
    ]
}

testJsonObject = {"calEventUID":"3dssafibq1agrg3kp8gu4kne5k","eventOwner":"fakerachellette@gmail.com","status":"confirmed","eventStart":"2023-06-02T17:45:00+12:00","eventEnd":"2023-06-02T18:15:00+12:00","eventUpdated":"2023-06-02T03:03:16.944Z","eventSumm":"Fakee ChrisAnother458"}

lambda_handler(testevent, "")

# except (Exception, psycopg2.DatabaseError) as error:
#         print(error)
# finally:
#     if conn is not None:
#         conn.close()

#### NOT YET INSERTED!!!
# #For testing - Example of what a pulled event obj will look like:
# event_obj = {"calEventUID":"0v4fs27ntvr0d8nqo8v1uve7j5","eventOwner":"boostlymagic@gmail.com","status":"confirmed","eventStart":"2023-05-12T11:15:00+12:00","eventEnd":"2023-05-16T22:45:00+12:00","eventUpdated":"2023-05-16T05:56:33.006Z"}


# eventStart = event_obj['eventStart']

# event_date = eventStart # Assigning event_date to eventStart

# employingID = 1 # Not yet done, assuming we're accessing EmployeeID 1 for now
# # clientID = 1    # Simulating Chris record
 

# event_date = parser.parse(event_date, yearfirst=True, dayfirst=True)    # Converts date string to datetime format
# event_day = event_date.strftime('%A')                                   # Gets the day of the event
# event_time = event_date.hour                                            # Checks the starting hour of the event
# if event_time < 12:
#     event_timeofday = event_day + "AM"                                 # Concatenates to create a string with "daytype_timeofday"
# else:
#     event_timeofday = event_day + "PM"

# # event_date = event_date.strftime("%d-%m-%y")

# print("event time  is ", event_timeofday)
# print("day of e_date is: ", event_day)
# # print("event date converted is ", event_date)

# # Now to check client preference table to see if there's anyone who wants that timeslot
# def iter_row(cursor, size=10):
#     while True:
#         rows = cursor.fetchmany(size)
#         if not rows:
#             break
#         for row in rows:
#             yield row

# try:
#     cursor = conn.cursor()
#     check_pref = """ SELECT * FROM ClientPref
#                         WHERE employID=%s """ 
#     cursor.execute(check_pref, (str(employingID)))
#     record = cursor.fetchall()
#     # for row in iter_row(cursor, 10):
#     #             print(row)
#     print(record)
#     print(record[0][2])
#     cursor.close()

# except (Exception, psycopg2.DatabaseError) as error:
#         print(error)
# finally:
#     if conn is not None:
#         conn.close()

#### --END NOT YET INSERTED!!!



# """ CREATE TABLE if not exists Event ( 
#     calEventUID varchar(255) NOT NULL, 
#     eventOwner varchar(255) NOT NULL, 
#     status varchar(255) NOT NULL, 
#     eventStart Date NOT NULL, 
#     eventEnd Date NOT NULL, 
#     eventUpdated Date NOT NULL, PRIMARY KEY (calEventUID)) """

# """ CREATE TABLE if not exists Client ( 
#     clientID SERIAL PRIMARY KEY, 
#     clientFirstName VARCHAR(255) NOT NULL, 
#     clientLastName VARCHAR(255) NOT NULL, 
#     clientEmail VARCHAR(255) NOT NULL, 
#     clientMobile INT NOT NULL) """

# """ CREATE TABLE if not exists AvailTimes ( 
#     availID SERIAL PRIMARY KEY,
#     days VARCHAR(16) UNIQUE) """

# 'ERROR:  duplicate key value violates unique constraint "availtimes_days_key"'

# """ 
# BEGIN
    # INSERT INTO AvailTimes (days)
    # VALUES 
    # ('MondayAM'), ('MondayAM'), ('MondayPM'), ('TuesdayAM'), ('TuesdayPM'), ('WednesdayAM'), ('WednesdayPM'), 
    # ('ThursdayAM'), ('ThursdayPM'), ('FridayAM'), ('FridayPM'), ('SaturdayAM'), ('SaturdayPM'),
    # ('SundayAM'), ('SundayPM');
# EXCEPTION WHEN unique_violation THEN
    # -- do nothing
# END; """

# """ CREATE TABLE if not exists ClientPref ( 
#     clientID INT NOT NULL PRIMARY KEY,
#     employID INT NOT NULL, 
#     availID INT NOT NULL,
#     minDuration INT not null) """


# DUMMY DATA
# """ INSERT INTO Client (clientFirstName, clientLastName, clientEmail, clientMobile)
# VALUES 
# ('Chris', 'Chong', 'chris.chonghuihui@gmail.com', '0220660122') ,
# ('Ana', 'Karpova', 'ana@gmail.com', '1234567'),
# ('Lala', 'Wally', 'lala@gmail.com', '9876543') """

# Data needed for Employee table: employeeID, companyID, emailAddress, 


# Dummy values inserting all mornings into Chris (client1), all afternoons into Ana (client2), and mixed bag into lala for Employee1
# """ INSERT INTO ClientPref
# VALUES 
# (1, 1, 1), (1, 1, 3), (1, 1, 5), (1, 1, 7), (1, 1, 9),
# (1, 1, 11), (1, 1, 13),
# (2, 1, 2), (2, 1, 4), (2, 1, 6), (2, 1, 8), (2, 1, 10),
# (2, 1, 12), (2, 1, 14),
# (3, 1, 1), (3, 1, 2), (3, 1, 6), (3, 1, 7), (3, 1, 14)"""